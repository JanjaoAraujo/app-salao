import axios from 'axios';

const api = axios.create({
  baseURL: 'http://SEU_IP:8000',
  timeout: 5000,
});

export default api;
