import React, { useEffect, useState } from 'react';
import { FlatList, Text, View, Alert } from 'react-native';
import api from '../services/api';
import { Screen, Card, AppInput, AppButton } from '../components/UI';

export default function ServicesScreen() {
  const [services, setServices] = useState([]);
  const [name, setName] = useState('');
  const [duration, setDuration] = useState('');
  const [price, setPrice] = useState('');

  const load = async () => {
    try {
      const res = await api.get('/services');
      setServices(res.data);
    } catch {
      setServices([]);
    }
  };

  const save = async () => {
    if (!name || !duration || !price) {
      Alert.alert('Atenção', 'Preencha nome, duração e preço.');
      return;
    }
    await api.post('/services', {
      name,
      duration_minutes: Number(duration),
      price: Number(price),
    });
    setName('');
    setDuration('');
    setPrice('');
    load();
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <Screen title="Serviços" subtitle="Organize seus atendimentos e preços">
      <FlatList
        ListHeaderComponent={
          <View>
            <Card>
              <AppInput value={name} onChangeText={setName} placeholder="Nome do serviço" />
              <AppInput value={duration} onChangeText={setDuration} placeholder="Duração em minutos" keyboardType="numeric" />
              <AppInput value={price} onChangeText={setPrice} placeholder="Preço" keyboardType="numeric" />
              <AppButton title="Salvar serviço" onPress={save} />
            </Card>
            <Text style={{ marginVertical: 8, color: '#71718C', fontWeight: '600' }}>Serviços cadastrados</Text>
          </View>
        }
        data={services}
        keyExtractor={(item, index) => item._id || String(index)}
        renderItem={({ item }) => (
          <Card>
            <Text style={{ fontSize: 17, fontWeight: '700' }}>{item.name}</Text>
            <Text style={{ marginTop: 6, color: '#44445A' }}>{item.duration_minutes} min</Text>
            <Text style={{ marginTop: 4, color: '#7C3AED', fontWeight: '700' }}>R$ {Number(item.price || 0).toFixed(2)}</Text>
          </Card>
        )}
        showsVerticalScrollIndicator={false}
      />
    </Screen>
  );
}
